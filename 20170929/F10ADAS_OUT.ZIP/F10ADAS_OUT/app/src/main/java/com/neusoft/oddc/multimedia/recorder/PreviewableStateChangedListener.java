package com.neusoft.oddc.multimedia.recorder;


public interface PreviewableStateChangedListener {

    void onPrepared();

    void onUnPrepared();

}
