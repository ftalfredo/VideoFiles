package com.neusoft.oddc.oddc.neusoft;

import android.os.Process;
import android.util.Log;

import com.neusoft.oddc.activity.PreviewActivity;
import com.neusoft.oddc.oddc.model.ODDCJob;
import com.neusoft.oddc.oddc.model.ODDCTask;
import com.neusoft.oddc.oddc.model.TaskType;
import com.neusoft.oddc.oddc.restclient.RESTController;
import com.neusoft.oddc.oddc.utilities.Utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by yzharchuk on 8/8/2017.
 */

public class JobManager
{
    private RESTController restController;

    private boolean isProcessingJobs = false;
    private Timer pingTimer;
    private int pingFrequency = 10000;
    private ODDCclass oddc;

    public void setAdasEnabled(boolean adasEnabled)
    {
        this.adasEnabled = adasEnabled;
    }

    private boolean adasEnabled = false;

    private static JobManager instance;

    public JobManager(String url)
    {
        instance = this;
        restController = new RESTController(url);
    }
    public boolean isAdasEnabled()
    {
        return adasEnabled;
    }
    public void setODDC(ODDCclass oddc)
    {
        this.oddc = oddc;
    }
    public void setPingFrequency(int value)
    {
        pingFrequency = value;
    }
    public static JobManager getInstance()
    {
        return instance;
    }

    public static ODDCTask getDummyTask()
    {
        ODDCTask task = new ODDCTask();
        task.setType(TaskType.JOB_REQUEST);
        HashMap<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("longitude", -118.308784484863);
        parameters.put("latitude", 33.8489532470703);
        parameters.put("vehicleID", "1B3LC46R38N557180");
        return task;
    }

    private ArrayList<ODDCJob> getJobsFromServer(ODDCTask task)
    {
//        runOnUiThread(new Runnable() {
//            public void run() {
//                Toast.makeText(MyApplication.currentActivity, "Reqesting Job List" , Toast.LENGTH_SHORT ).show();
//            }
//        });

        Utilities.showToastMessage("Reqesting Job List");

        ArrayList<ODDCJob>jobs = restController.getJobList(task);
        return jobs;
    }

    public ArrayList<ODDCJob> getJobList(ODDCTask task)
    {
        return getJobsFromServer(task);
    }

    public void processJobs(ArrayList<ODDCJob> jobs)
    {
        if(isProcessingJobs)
        {
            return;
        }

        isProcessingJobs = true;

        if(jobs.size() > 0)
        {
            for(ODDCJob job: jobs)
            {
                processJob(job);
            }

            isProcessingJobs = false;
        }
    }

    private void processJob(ODDCJob job)
    {
        ArrayList <ODDCTask> tasks = job.getTasks();

        if(tasks.size() > 0)
        {
            for(ODDCTask task : tasks)
            {
                processTask(task);
            }
        }
    }

    public void processTask(ODDCTask task)
    {
        switch (task.getType())
        {
            case SELECTIVE_UPLOAD:
                processSelectiveUploadTask(task);
                break;
            case UPLOAD:
                processUploadTask();
                break;
            case STOP:
                processStopTask();
                break;
            case TERMINATE:
                processTerminateTask();
                break;
            case RESUME:
//                nsh.resume();
                processResumedTask();
                break;
            default:
                Log.d("processTask", "No tasks from Server.");
        }
    }

    private void processResumedTask()
    {
        //TODO FTCA implementation here
        Log.d("JobManager", "processResumedTask");
        Utilities.showToastMessage("Process Task: Resume");

        if(oddc == null)
        {
            Log.d("processResumedTask", "ODDC is not initialized.");
            return;
        }
    }

    private void processStopTask()
    {
        Log.d("JobManager", "processStopTask");
        Utilities.showToastMessage("Process Task: Stop");

        adasEnabled = false;

        PreviewActivity previewActivity = PreviewActivity.getInstance();
        if(previewActivity != null)
        {
            previewActivity.endRecording();
        }
    }

    private void processTerminateTask()
    {
        //TODO FTCA implementation here
        Log.d("JobManager", "processTerminateTask");

        if(oddc == null)
        {
            Log.d("processTerminateTask", "ODDC is not initialized.");
            return;
        }
    }

    private void processUploadTask()
    {
        //TODO FTCA implementation here
        Log.d("JobManager", "processUploadTask");

        Utilities.showToastMessage("Process Task: Upload");

        adasEnabled = true;

        //NOTE: In case user is already in the PreviewActivity screen, start recording.
        PreviewActivity previewActivity = PreviewActivity.getInstance();
        if(previewActivity != null)
        {
            previewActivity.beginRecording();
        }
    }

    private void processParametersTask()
    {
        //TODO FTCA implementation here
        Log.d("JobManager", "processParametersTask");

        if(oddc == null)
        {
            Log.d("processParametersTask", "ODDC is not initialized.");
            return;
        }

        //TODO: Parse the parameter list

        //TODO: Call ODDC to modify parameter value based on the parameter name...
    }

    private void processPropertiesTask()
    {
        //TODO FTCA implementation here
        Log.d("JobManager", "processPropertiesTask");

        if(oddc == null)
        {
            Log.d("processPropertiesTask", "ODDC is not initialized.");
            return;
        }

        //TODO: Parse the Properties list and corresponding value(s)
        //      Part of the parameters for this command should include the file name of the media file.

        //TODO: Call ODDC to move the file(s) to/from protected folder based on boolean value
        //      True - Move to Protected Folder: Files in this folder will not be deleted during File Manager clean up
        //      False - Move to Normal Folder: Files in this folder can be deleted during File Manager clean up
    }

    private void processSelectiveUploadTask(ODDCTask task)
    {
        Utilities.showToastMessage("Process Task: Selective");

        oddc.selectiveUpload(task);
    }

    public void startPingTimer()
    {
        pingTimer = new Timer();
        pingTimer.schedule(new TimerTask() {
            @Override
            public void run()
            {
                Log.d("ODDC THREAD ","JobManager.PingTimer TID="+String.valueOf(Process.myTid()));

                //TODO: Pull Job List from ODDC Server
                ODDCTask tempTask = getDummyTask();
                ArrayList<ODDCJob> jobs = getJobsFromServer(tempTask);

                //TODO: Process each Job
                if(jobs != null && jobs.size() > 0)
                {
                    Log.d("ODDC PINGTIMER","getJobsFromServer REPLY "+jobs.size()+" jobs");
                    processJobs(jobs);
                }
            }
        }, 1000, pingFrequency);
    }

    public void stopPingTimer()
    {
        if(pingTimer != null)
        {
            pingTimer.cancel();
            pingTimer.purge();
        }
    }
}
