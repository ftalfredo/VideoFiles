package com.neusoft.oddc.widget.eventbus;

public class EventStopDataCollection {
}
