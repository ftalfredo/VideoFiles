package com.neusoft.oddc.fragment;

import android.support.v4.app.Fragment;

public class BaseFragment extends Fragment {
}
