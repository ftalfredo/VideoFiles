package com.neusoft.oddc.db;

public class Empty {
}
