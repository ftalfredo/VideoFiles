package com.neusoft.oddc.activity;


public class LoginActivity extends BaseActivity {
}
